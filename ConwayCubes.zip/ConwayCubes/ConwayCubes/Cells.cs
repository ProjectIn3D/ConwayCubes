﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConwayCubes
{
    internal class Cells
    {
        public int LocationXAxis, LocationYAxis, LocationZAxis, NumberOfNearbyCells = 0;

        private bool[,,] ListOfNearbyCells = new bool[3, 3, 3]
        {
                { {false, false, false}, {false, false, false}, {false, false, false} },
                { {false, false, false}, {false, false, false}, {false, false, false} },
                { {false, false, false}, {false, false, false}, {false, false, false} }
        };
        

        public Cells(int Xpoint, int Ypoint, int Zpoint)
        {
            LocationXAxis = Xpoint;
            LocationYAxis = Ypoint;
            LocationZAxis = Zpoint;
        }

        public void AddNearbyCells(int Xpoint, int Ypoint, int Zpoint)
        {
            ListOfNearbyCells[Xpoint, Ypoint, Zpoint] = true;
            NumberOfNearbyCells++;
        }

        public bool GetAliveNearbyCells(int Xpoint, int Ypoint, int Zpoint)
        {
            return ListOfNearbyCells[Xpoint + 1,Ypoint + 1, Zpoint + 1];
        }

    }
}
