﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConwayCubes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Grid3D Grid = new Grid3D();
            bool PlacingCells = true , Game = false;
            while (PlacingCells == true)
            {
                Console.WriteLine($"Current Rules ({Grid.GetLowerSurvivalBound()}{Grid.GetUpperSurvivalBound()}{Grid.GetLowerBirthBound()}{Grid.GetUpperBirthBound()})\nCurrent Size 10 by 10 by 10\nOptions:\nPlace\nRemove\nMap\nChange\nStart");
                string input = Convert.ToString(Console.ReadLine()).ToLower();
                switch (input)
                {
                    case "g":
                        Grid.GetListOfLocation();
                        Console.ReadLine();

                        break;

                    case "map":
                    case "m":
                        GetMap();
                        Console.WriteLine("Enter any key to continue");
                        Console.ReadLine();
                        break;
                    default:
                    Console.Clear();
                    break;
                    case "place":
                    case "p":
                        Console.WriteLine("Input list of points in this format (x,y,z:x,y,z:x,y,z)");
                        string UnsortedList = Console.ReadLine();
                        List<string> SortedList = UnsortedList?.Split(';').ToList();
                        for (int listcounter = 0; listcounter < SortedList.Count(); listcounter++)
                        {
                            List<int> NumberSortedList = new List<int>(Array.ConvertAll(SortedList[listcounter]?.Split(','), int.Parse));
                            if (Grid.GetValueAtPoint(NumberSortedList[0]-1, NumberSortedList[1]-1, NumberSortedList[2] - 1) == true)
                            {
                                Console.WriteLine($"There is already an alive cell at {NumberSortedList[0]},{NumberSortedList[1]},{NumberSortedList[2]}");
                            }
                            if (NumberSortedList[0] == 11 || NumberSortedList[1] == 11 || NumberSortedList[2] == 11)
                            {
                                Console.WriteLine($"At ({NumberSortedList[0] - 1},{NumberSortedList[1] - 1},{NumberSortedList[2] - 1}), there is a value above 10");
                            }
                            else
                            {
                                Grid.CurrentPlaceCells(NumberSortedList[0] - 1, NumberSortedList[1] - 1, NumberSortedList[2] - 1);
                            }
                        }
                        Console.ReadLine();
                        break;

                    case "remove":
                    case "r":
                        Console.WriteLine("Input list of points in this format (x,y,z:x,y,z:x,y,z)");
                        string DeletedUnsortedList = Console.ReadLine();
                        List<string> DeletedSortedList = new List<string>(DeletedUnsortedList?.Split(';').ToList());
                        for (int listcounter = 0; listcounter < DeletedSortedList.Count(); listcounter++)
                        {
                            List<int> NumberSortedList = new List<int>(Array.ConvertAll(DeletedSortedList[listcounter]?.Split(','), int.Parse));
                            if (Grid.GetValueAtPoint(NumberSortedList[0] - 1, NumberSortedList[1] - 1, NumberSortedList[2] - 1) == false)
                            {
                                Console.WriteLine($"There is no alive cell at {NumberSortedList[0]},{NumberSortedList[1]},{NumberSortedList[2]}");
                                Console.ReadLine();
                            }
                            if (NumberSortedList[0] == 11 || NumberSortedList[1] == 11 || NumberSortedList[2] == 11)
                            {
                                Console.WriteLine($"At ({NumberSortedList[0] - 1},{NumberSortedList[1] - 1},{NumberSortedList[2] - 1}), there is a value above 10");
                                Console.ReadLine();
                            }
                            else
                            {
                                Grid.RemoveCells(NumberSortedList[0] - 1, NumberSortedList[1] - 1, NumberSortedList[2] - 1);
                            }
                        }
                        break;

                    case "change":
                    case "c":
                        Console.WriteLine("Format your rules as (0000)\nEnter: ");
                        string rules = Console.ReadLine();
                        int rule1 = Convert.ToInt32(rules.Substring(0, 1));
                        Grid.SetLowerSurvivalBound(rule1);
                        int rule2 = Convert.ToInt32(rules.Substring(1, 1));
                        Grid.SetUpperSurvivalBound(rule2);
                        int rule3 = Convert.ToInt32(rules.Substring(2, 1));
                        Grid.SetLowerBirthBound(rule3);
                        int rule4 = Convert.ToInt32(rules.Substring(3, 1));
                        Grid.SetUpperBirthBound(rule4);
                        break;

                    case "start":
                    case "s":
                        Console.Clear();
                        PlacingCells = false;
                        Game = true;
                        break;
                }
                Console.Clear(); 
            }

            while (Game == true)
            {
                Grid.Algorithm();
                if (Grid.CheckAliveCells() == true) // Is there any cells alive?
                {
                    Game = false; // No, End program
                    Console.WriteLine("No cells alive");
                }
                else // Yes
                {
                    GetMap(); // Show map
                    Console.WriteLine("Press to Continue");
                    Console.ReadLine();
                    Console.Clear();
                }
            }

            void GetMap()
            {
                for (int yAxisValue = -1; yAxisValue < 10; yAxisValue++)
                { 
                    if (yAxisValue == -1)
                    {
                        for (int ZAxisTitle = 0; ZAxisTitle < 5; ZAxisTitle++)
                        {
                            Console.Write($"Z Axis: {ZAxisTitle + 1}");
                            Console.Write("                  ");
                        }
                        Console.WriteLine();
                    }
                    else
                    {
                        for (int zAxisValue = 0; zAxisValue < 5; zAxisValue++)
                        {
                            for (int xAxisValue = 0; xAxisValue < 10; xAxisValue++)
                            {
                                if (Grid.GetValueAtPoint(xAxisValue, yAxisValue, zAxisValue) == true)
                                {
                                    Console.Write("0 ");
                                }
                                else
                                {
                                    Console.Write("- ");
                                }
                            }
                            Console.Write("       ");
                        }
                    }
                    Console.WriteLine();
                }
                Console.WriteLine();
                for (int yAxisValue = -1; yAxisValue < 10; yAxisValue++)
                {
                    if (yAxisValue == -1)
                    {
                        for (int ZAxisTitle = 5; ZAxisTitle < 10; ZAxisTitle++)
                        {
                            Console.Write($"Z Axis: {ZAxisTitle + 1}");
                            Console.Write("                  ");
                        }
                        Console.WriteLine();
                    }
                    else
                    {
                        for (int zAxisValue = 5; zAxisValue < 10; zAxisValue++)
                        {
                            for (int xAxisValue = 0; xAxisValue < 10; xAxisValue++)
                            {
                                if (Grid.GetValueAtPoint(xAxisValue, yAxisValue, zAxisValue) == true)
                                {
                                    Console.Write("0 ");
                                }
                                else
                                {
                                    Console.Write("- ");
                                }
                            }
                            Console.Write("       ");
                        }
                    }
                    Console.WriteLine();
                }
            }
        }
    }
}
