﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConwayCubes
{
    internal class Grid3D
    {
        private List<Cells> CurrentCells = new List<Cells>();
        private bool[,,] CurrentLocation = new bool[10, 10, 10]
        {
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },

        };

        private List<Cells> NextCells = new List<Cells>();
        private bool[,,] NextLocation = new bool[10, 10, 10]
        {
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
            { {false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false},{false, false, false, false, false, false, false, false, false, false}, {false, false, false, false, false, false, false, false, false, false} },
        };

        // add loop 
        public void GetListOfLocation()
        {
            for (int i = 0; i < CurrentCells.Count(); i++)
            {
                Console.WriteLine($"{CurrentCells[i].LocationXAxis},{CurrentCells[i].LocationYAxis},{CurrentCells[i].LocationZAxis}");
            }
        }

        public Grid3D()
        {
        }

        // Rules
        // Default
        private int LowerSurvivalBound = 1, UpperSurvivalBound = 5, LowerBirthBound = 1, UpperBirthBound = 9;

        // Get Method
        public int GetLowerSurvivalBound()
        {
            return LowerSurvivalBound;
        }

        public int GetUpperSurvivalBound()
        {
            return UpperSurvivalBound;
        }
        public int GetLowerBirthBound()
        {
            return LowerBirthBound;
        }
        public int GetUpperBirthBound()
        {
            return UpperBirthBound;
        }

        // Set Method

        public void SetLowerSurvivalBound(int SetValue)
        {
            LowerSurvivalBound = SetValue;
        }

        public void SetUpperSurvivalBound(int SetValue)
        {
            UpperSurvivalBound = SetValue;
        }
        public void SetLowerBirthBound(int SetValue)
        {
            LowerBirthBound = SetValue;
        }
        public void SetUpperBirthBound(int SetValue)
        {
            UpperBirthBound = SetValue;
        }


        // Planning Phase
        // Command For Mapping
        public bool GetValueAtPoint(int Xpoint, int Ypoint, int Zpoint)
        {
            bool CheckingIfAlive = false;
            if (CurrentLocation[Xpoint, Ypoint, Zpoint] == true)
            {
                CheckingIfAlive = true;
            }
            return CheckingIfAlive;
        }

        // Placing & Removing Cells
        public void CurrentPlaceCells(int Xpoint, int Ypoint, int Zpoint)
        {
            CurrentCells.Add(new Cells(Xpoint, Ypoint, Zpoint));
            CurrentLocation[Xpoint, Ypoint, Zpoint] = true;
        }

        public void NextPlaceCells(int Xpoint, int Ypoint, int Zpoint)
        {
            NextCells.Add(new Cells(Xpoint, Ypoint, Zpoint));
            NextLocation[Xpoint, Ypoint, Zpoint] = true;
        }

        public void RemoveCells(int Xpoint, int Ypoint, int Zpoint)
        {
            for (int CellsCounter = 0; CellsCounter < CurrentCells.Count; CellsCounter++)
            {
                if (CurrentCells[CellsCounter].LocationXAxis == Xpoint)
                {
                    if (CurrentCells[CellsCounter].LocationYAxis == Ypoint)
                    {
                        if (CurrentCells[CellsCounter].LocationZAxis == Zpoint)
                        {
                            CurrentCells.RemoveAt(CellsCounter);
                        }
                    }
                }
            }
            CurrentLocation[Xpoint, Ypoint, Zpoint] = false;
        }


        // Alorgithm
        // Check for alive Cells
        public bool CheckAliveCells()
        {
            bool Check = false;
            if (CurrentCells.Count() == 0)
            {
                Check = true;
            }
            return Check;
        }

        // Start Algorithm
        // ERROR: DOES NOT UPDATE ANY CELLS ON A HIGHER PLANE EG 5,5,5 DOES NOT INTERACT WITH 5,5,6 OR 5,6,5 OR 6,5,5 ... ETC
        // ERROR: DOES NOT WORK WITH 4555 RULES ONLY 0509 AND WITH A DRAWBACK OF NO CELLS SPAWNING IN WITH 0 ALIVE AROUND IT
        public void Algorithm()
        {
            AddCurrentAdjustedCells(); // Update the cells to have Nearby Cells
            for (int CellsCounter = 0; CellsCounter < CurrentCells.Count(); CellsCounter++) // check one of the cells in a list
            {
                if (CheckEnoughNearbyCells(CurrentCells[CellsCounter])) // check if there is enough nearby cells to live
                {
                    NextPlaceCells(CurrentCells[CellsCounter].LocationXAxis, CurrentCells[CellsCounter].LocationYAxis, CurrentCells[CellsCounter].LocationZAxis); // yes, then survive for next generation
                } // no, then doesnt survive

                // checking if dead cells around the selected cell are alive in next generation

                for (int CloseCellsAxisX = -1; CloseCellsAxisX < 2; CloseCellsAxisX++)
                {
                    for (int CloseCellsAxisY = -1; CloseCellsAxisY < 2; CloseCellsAxisY++)
                    {
                        for (int CloseCellsAxisZ = -1; CloseCellsAxisZ < 2; CloseCellsAxisZ++)
                        {
                            if (CurrentCells[CellsCounter].GetAliveNearbyCells(CloseCellsAxisX, CloseCellsAxisY, CloseCellsAxisZ) == false) // check dead cells
                            {
                                if (CheckNearbyCellsForEnoughCells(CurrentCells[CellsCounter].LocationXAxis + CloseCellsAxisX, CurrentCells[CellsCounter].LocationYAxis + CloseCellsAxisY, CurrentCells[CellsCounter].LocationZAxis +CloseCellsAxisZ) == true)
                                {
                                    NextPlaceCells(CurrentCells[CellsCounter].LocationXAxis + CloseCellsAxisX, CurrentCells[CellsCounter].LocationYAxis + CloseCellsAxisY, CurrentCells[CellsCounter].LocationZAxis + CloseCellsAxisZ);
                                }
                            }
                        }
                    }
                }
            }
            NextGenerationToCurrentGeneration();
        }

        // Add cells in a 1 cube area into ListOfNearbyCells

        public void AddCurrentAdjustedCells()
        {
            for (int CellsCounter = 0; CellsCounter < CurrentCells.Count()-1; CellsCounter++)
            {
                for (int CloseCellsAxisX = 0; CloseCellsAxisX < 3; CloseCellsAxisX++)
                {
                    for (int CloseCellsAxisY = 0; CloseCellsAxisY < 3; CloseCellsAxisY++)
                    {
                        for (int CloseCellsAxisZ = 0; CloseCellsAxisZ < 3; CloseCellsAxisZ++)
                        {
                            if (CurrentCells[CellsCounter].LocationXAxis + CloseCellsAxisX - 1 <= 9 && CurrentCells[CellsCounter].LocationXAxis + CloseCellsAxisX - 1 >= 0 && CurrentCells[CellsCounter].LocationYAxis + CloseCellsAxisY - 1 <= 9 && CurrentCells[CellsCounter].LocationYAxis + CloseCellsAxisY - 1 >= 0 &&  CurrentCells[CellsCounter].LocationZAxis + CloseCellsAxisZ - 1 <= 9 && CurrentCells[CellsCounter].LocationZAxis + CloseCellsAxisZ - 1 >= 0 && !(CloseCellsAxisX == 1 && CloseCellsAxisY == 1 && CloseCellsAxisZ == 1))
                            {
                                if (CurrentLocation[CurrentCells[CellsCounter].LocationXAxis + CloseCellsAxisX - 1, CurrentCells[CellsCounter].LocationYAxis + CloseCellsAxisY - 1, CurrentCells[CellsCounter].LocationZAxis + CloseCellsAxisZ - 1] == true)
                                {
                                    CurrentCells[CellsCounter].AddNearbyCells(CloseCellsAxisX, CloseCellsAxisY, CloseCellsAxisZ);
                                }
                                else
                                {

                                }
                            }
                            
                        }
                    }
                }
            }
        }

        // Check If there is enough cells to stay alive

        public bool CheckEnoughNearbyCells(Cells cell)
        {
            bool Check = false;
            if (LowerSurvivalBound <= NumberOfAliveCellsAroundPoint(cell.LocationXAxis, cell.LocationYAxis, cell.LocationZAxis) && NumberOfAliveCellsAroundPoint(cell.LocationXAxis, cell.LocationYAxis, cell.LocationZAxis) <= UpperSurvivalBound) // Default: 4 <= x <= 5
            {
                Check = true;
            }
            return Check;
        }

        // check if any nearby dead cells can live

        public bool CheckNearbyCellsForEnoughCells(int Xpoint, int Ypoint, int Zpoint)
        {
            bool Check = false;
            if (LowerBirthBound <= NumberOfAliveCellsAroundPoint(Xpoint, Ypoint, Zpoint) && NumberOfAliveCellsAroundPoint(Xpoint, Ypoint, Zpoint) <= UpperBirthBound) // Default: x == 5
            {
                Check = true;
            }
            return Check;
        }

        // check number of nearby cell around a specific point in location

        public int NumberOfAliveCellsAroundPoint(int Xpoint, int Ypoint, int Zpoint)
        {
            int NumberOfAliveCells = 0;
            for (int Xaxis = -1; Xaxis < 2; Xaxis++)
            {
                for (int Yaxis = -1; Yaxis < 2; Yaxis++)
                {
                    for (int Zaxis = -1; Zaxis < 2; Zaxis++)
                    {
                        if (Xpoint + Xaxis <= 9 && Ypoint + Yaxis <= 9 && Zpoint + Zaxis <= 9 && Xpoint + Xaxis >= 0 && Ypoint + Yaxis >= 0 && Zpoint + Zaxis >= 0 && !(Xaxis == 0 && Yaxis == 0 && Zaxis == 0))
                        {
                            if (CurrentLocation[Xpoint + Xaxis, Ypoint + Yaxis, Zpoint + Zaxis] == true)
                            {
                                NumberOfAliveCells++;
                            }
                                    
                        }
                    }
                }
            }
            return NumberOfAliveCells;
        }

        // Make next generation of cells into the current generation of cells

        public void NextGenerationToCurrentGeneration()
        {
            ClearCurrentLocation();
            CurrentCells.Clear();
            TransferNextCellsToCurrentCells();
            ClearNextLocation();
            NextCells.Clear();
        }

        // Clear Current Location

        public void ClearCurrentLocation()
        {
            for (int CellsCounter = 0; CellsCounter < CurrentCells.Count(); CellsCounter++)
            {
                CurrentLocation[CurrentCells[CellsCounter].LocationXAxis, CurrentCells[CellsCounter].LocationYAxis, CurrentCells[CellsCounter].LocationZAxis] = false;
            }
        }

        // Clear Next Location

        public void ClearNextLocation()
        {
            for (int CellsCounter = 0; CellsCounter < NextCells.Count(); CellsCounter++)
            {
                NextLocation[NextCells[CellsCounter].LocationXAxis, NextCells[CellsCounter].LocationYAxis, NextCells[CellsCounter].LocationZAxis] = false;
            }
        }

        // Transfer Cells from next to current

        public void TransferNextCellsToCurrentCells()
        {
            for (int CellsCounter = 0; CellsCounter < NextCells.Count(); CellsCounter++)
            {
                CurrentPlaceCells(NextCells[CellsCounter].LocationXAxis, NextCells[CellsCounter].LocationYAxis, NextCells[CellsCounter].LocationZAxis);
            }
        }
    }
}
